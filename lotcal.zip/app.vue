<script setup lang="ts">
useHead({
  title: 'Lot Calculator',
  meta: [
    { name: 'description', content: 'My amazing site.' },
    { name: 'theme-color', content: '#ffffff' },
  ],
  link: [
    {
      rel: 'apple-touch-icon',
      href: '/apple-touch-icon-180x180.png',
      sizes: '180x180',
    },
    {
      rel: 'icon',
      href: '/favicon.ico',
    },
  ]
  // bodyAttrs: {
  //   class: 'test'
  // },
  // script: [ { innerHTML: 'console.log(\'Hello world\')' } ]
})

// If you want to use it in setup, import from the nuxtApp.
const { $pwa }: any = useNuxtApp()

function naiveRound(num: number, decimalPlaces = 1) {
    var p = Math.pow(10, decimalPlaces)
    return Math.round(num * p) / p
}

function currencyFormat(num: number, exchangeRate = 1) {
  return num ? new Intl.NumberFormat('vi-VN', { style: 'currency', currency: 'VND' }).format(
    (num * exchangeRate),
  ) : 0
}

const pipvalue = ref(10)
const exchangeRate = ref(25500)
const slpip = ref(10)
const tppip = ref(20)
const riskRatio = ref(2)
const balance = ref(200)
const rr = computed(() => slpip.value ? tppip.value / slpip.value : 0)
const slvalue = computed(() => rr.value ? balance.value * riskRatio.value / 100 : 0)
const tpvalue = computed(() => slvalue.value * rr.value)
const slvalueVnd = computed(() => currencyFormat(slvalue.value, exchangeRate.value))
const tpvalueVnd = computed(() => currencyFormat(tpvalue.value, exchangeRate.value))

// Lot Size = (Account Balance x Risk Percentage) / (Stop-Loss in Pips x Value per Pip)
const lot = computed(() => naiveRound((balance.value * riskRatio.value / 100) / (slpip.value * pipvalue.value), 2))

// LOG
const logs = ref<any>([])

function onLogAdd() {
  logs.value = [
    ...logs.value,
    ...[
      {
        slpip: slpip.value,
        slvalue: slvalue.value,
        tppip: tppip.value,
        tpvalue: tpvalue.value,
        checked: false,
      }
    ]
  ]

  onRate()
}

function onLogRemove(index: any) {
  if (index > -1)
    logs.value = [...logs.value.slice(0, index), ...logs.value.slice(index + 1)]

  onRate()
}

function onLogRemoveAll() {
  logs.value = []

  onRate()
}

function onLogCheck(index: any) {
  if (index > -1)
    logs.value[index].checked = !logs.value[index].checked

  onRate()
}

// Winrate
const winrate = ref(0)
const winEntries = ref(0)
const winValue = ref(0)
const winPip = ref(0)
const lossrate = computed(() => logs.value?.length ? 100 - winrate.value : 0)
const lossEntries = computed(() => logs.value?.length ? logs.value?.length - winEntries.value : 0)
const lossValue = ref(0)
const lossPip = ref(0)
const resultPip = ref(0)
const resultValue = ref(0)
const resultValueVnd = computed(() => currencyFormat(resultValue.value, exchangeRate.value))
const winValueVnd = computed(() => currencyFormat(winValue.value, exchangeRate.value))
const lossValueVnd = computed(() => currencyFormat(lossValue.value, exchangeRate.value))

async function onRate() {
  const checkedItem = logs.value.filter((x: any) => x?.checked)
  const uncheckedItem = logs.value.filter((x: any) => !x?.checked)

  winEntries.value = checkedItem?.length

  winrate.value = logs.value?.length && winEntries.value
    ? naiveRound(winEntries.value / logs.value?.length * 100, 0)
    : 0

  winValue.value = winEntries.value && winrate.value
    ? checkedItem?.reduce(
        (a: any, c: any) => a + c?.tpvalue,
        0,
      )
    : 0

  winPip.value = winEntries.value && winrate.value
    ? checkedItem?.reduce(
        (a: any, c: any) => a + c?.tppip,
        0,
      )
    : 0

  lossValue.value = lossEntries.value && lossrate.value
    ? uncheckedItem?.reduce(
        (a: any, c: any) => a + c?.slvalue,
        0,
      )
    : 0

  lossPip.value = lossEntries.value && lossrate.value
    ? uncheckedItem?.reduce(
        (a: any, c: any) => a + c?.slpip,
        0,
      )
    : 0

  resultPip.value = winPip.value - lossPip.value
  resultValue.value = winValue.value - lossValue.value
}
</script>

<template>
  <NuxtPwaManifest />
  <div class="antialiased text-gray-900 px-6">
    <div class="max-w-xl mx-auto py-12 divide-y md:max-w-4xl">
      <div class="py-8 print:hidden">
        <h1 class="text-4xl font-bold">Lot Calculator</h1>
        <p class="mt-2 text-lg text-gray-600">
          Calculate lot, pip and entry value based on account risk ratio and risk reward ratio.
        </p>
      </div>
      <div class="py-12 print:hidden">
        <h2 class="text-2xl font-bold">{{ lot }}</h2>
        <p class="mt-2 text-lg text-gray-600">{{ lot }} LOT; 1/{{ naiveRound(rr) }} RR;</p>
        <div class="mt-8 max-w-md">
          <div class="grid grid-cols-2 gap-6 mb-2">
            <label class="block">
              <span class="text-gray-700">SL pip</span>
              <input v-model="slpip" type="number" name="slpip" min="0" step="5" class="mt-1 block w-full" placeholder="SL pip" />
              <span v-if="slvalue" class="text-red-700 block font-bold px-3">{{ naiveRound(slvalue) }}$</span>
              <span v-if="slvalueVnd" class="text-red-700 block font-bold px-3">{{ slvalueVnd }}</span>
            </label>
            <label class="block">
              <span class="text-gray-700">TP pip</span>
              <input v-model="tppip" type="number" name="tppip" min="0" step="5" class="mt-1 block w-full" placeholder="TP pip" />
              <span v-if="tpvalue" class="text-green-700 block font-bold px-3">{{ naiveRound(tpvalue) }}$</span>
              <span v-if="tpvalueVnd" class="text-green-700 block font-bold px-3">{{ tpvalueVnd }}</span>
            </label>
          </div>
          <div class="grid grid-cols-2 gap-6 mb-2">
            <label class="block">
              <span class="text-gray-700">Risk (%)</span>
              <input v-model="riskRatio" type="number" name="riskRatio" min="0" class="mt-1 block w-full" placeholder="Risk (%)" />
            </label>
            <label class="block">
              <span class="text-gray-700">Balance ($)</span>
              <input v-model="balance" type="number" name="balance" min="0" step="50" class="mt-1 block w-full" placeholder="Balance ($)" />
            </label>
          </div>
          <div class="grid grid-cols-2 gap-6 mb-2">
            <label class="block">
              <span class="text-gray-700">Pip value</span>
              <input v-model="pipvalue" type="number" name="pipvalue" class="mt-1 block w-full" placeholder="Pip value" />
            </label>
            <label class="block">
              <span class="text-gray-700">Exchange rate</span>
              <input v-model="exchangeRate" type="number" name="exchangeRate" class="mt-1 block w-full" placeholder="Exchange rate" />
            </label>
          </div>
        </div>
        <button class="mt-2 px-4 py-2 font-semibold text-white bg-indigo-500 hover:bg-indigo-400 rounded-none shadow-sm" @click="onLogAdd">Add to log</button>
      </div>
      <div class="py-8">
        <h1 class="text-4xl font-bold">Entry Log</h1>
        <div class="bg-white py-2 mt-5">
          <div class="mx-auto">
            <dl class="grid grid-cols-3 gap-x-8 gap-y-16 text-center">
              <div class="mx-auto flex max-w-xs flex-col gap-y-4">
                <dt class="text-base leading-7 text-gray-600">No. Entries</dt>
                <dd class="order-first text-3xl font-semibold tracking-tight text-gray-900 sm:text-5xl">{{ logs?.length }}</dd>
                <dt
                  class="text-base text-gray-600"
                  :class="resultPip > 0 ? 'text-green-500' : (resultPip < 0 ? 'text-red-500' : '')"
                >
                  {{ resultPip }}pip. {{ naiveRound(resultValue) }}$. {{ resultValueVnd }}
                </dt>
              </div>
              <div class="mx-auto flex max-w-xs flex-col gap-y-4">
                <dt class="text-base leading-7 text-gray-600">Lossrate</dt>
                <dd class="order-first text-3xl font-semibold tracking-tight text-red-500 sm:text-5xl">{{ logs?.length ? lossrate : 0 }}%</dd>
                <dt class="text-base text-gray-600">{{ lossPip }}pip. {{ naiveRound(lossValue) }}$. {{ lossValueVnd }}</dt>
              </div>
              <div class="mx-auto flex max-w-xs flex-col gap-y-4">
                <dt class="text-base leading-7 text-gray-600">Winrate</dt>
                <dd class="order-first text-3xl font-semibold tracking-tight text-green-500 sm:text-5xl">{{ logs?.length ? winrate : 0 }}%</dd>
                <dt class="text-base text-gray-600">{{ winPip }}pip. {{ naiveRound(winValue) }}$. {{ winValueVnd }}</dt>
              </div>
            </dl>
          </div>
        </div>
        <div v-if="logs?.length" class="mt-8">
          <table class="border-collapse w-full border border-slate-400 bg-white text-sm shadow-sm">
            <thead class="bg-slate-50">
              <tr>
                <th class="w-1/8 print:w-1/12 border border-slate-300 font-semibold p-1 text-slate-900 text-center" rowspan="2">#</th>
                <th class="w-2/8 print:w-5/12 border border-slate-300 font-semibold p-1 text-slate-900 text-center" colspan="2">{{ lossEntries }} SL</th>
                <th class="w-2/8 print:w-5/12 border border-slate-300 font-semibold p-1 text-slate-900 text-center" colspan="2">{{ winEntries }} TP</th>
                <th class="w-1/8 print:w-1/12 border border-slate-300 font-semibold p-1 text-slate-900 text-center" rowspan="2">Win</th>
                <th class="w-1/8 border border-slate-300 font-semibold p-1 text-slate-900 text-center print:hidden" rowspan="2">
                  <button class="text-red-500" @click="onLogRemoveAll">
                    <svg xmlns="http://www.w3.org/2000/svg" x="0px" y="0px" width="24" height="24" viewBox="0,0,300,150">
                      <g fill="#b91c1c" fill-rule="nonzero" stroke="none" stroke-width="1" stroke-linecap="butt" stroke-linejoin="miter" stroke-miterlimit="10" stroke-dasharray="" stroke-dashoffset="0" font-family="none" font-weight="none" font-size="none" text-anchor="none" style="mix-blend-mode: normal"><g transform="scale(16,16)"><path d="M6.49609,1c-0.82031,0 -1.49609,0.67578 -1.49609,1.49609v0.50391h-3v1h1v8.5c0,0.82813 0.67188,1.5 1.5,1.5h6c0.82813,0 1.5,-0.67187 1.5,-1.5v-8.5h1v-1h-3v-0.50391c0,-0.82031 -0.67578,-1.49609 -1.49609,-1.49609zM6.49609,2h2.00781c0.28125,0 0.49609,0.21484 0.49609,0.49609v0.50391h-3v-0.50391c0,-0.28125 0.21484,-0.49609 0.49609,-0.49609zM5,5h1v7h-1zM7,5h1v7h-1zM9,5h1v7h-1z"></path></g></g>
                    </svg>
                  </button>
                </th>
              </tr>
              <tr>
                <th class="w-1/6 border border-slate-300 font-semibold p-1 text-slate-900 text-center">pip</th>
                <th class="w-1/6 border border-slate-300 font-semibold p-1 text-slate-900 text-center">value</th>
                <th class="w-1/6 border border-slate-300 font-semibold p-1 text-slate-900 text-center">pip</th>
                <th class="w-1/6 border border-slate-300 font-semibold p-1 text-slate-900 text-center">value</th>
              </tr>
            </thead>
            <tbody>
              <tr
                v-for="(item, index) in logs"
                :key="`log${index}`"
              >
                <td class="border border-slate-300 p-1 text-slate-500 text-center">{{ index + 1 }}</td>
                <td class="border border-slate-300 p-1 text-slate-500 text-center">{{ item?.slpip }}</td>
                <td class="border border-slate-300 p-1 text-slate-500 text-center">{{ naiveRound(item?.slvalue) }}$</td>
                <td class="border border-slate-300 p-1 text-slate-500 text-center">{{ item?.tppip }}</td>
                <td class="border border-slate-300 p-1 text-slate-500 text-center">{{ naiveRound(item?.tpvalue) }}$</td>
                <td class="border border-slate-300 p-1 text-slate-500 text-center">
                  <input :id="`wRhFJS${index}`" type="checkbox" :checked="item?.checked" class="print:hidden" @click="onLogCheck(index)" />
                  <span class="hidden print:block">
                    {{ item?.checked ? 'x' : '' }}
                  </span>
                </td>
                <td class="border border-slate-300 p-1 text-slate-500 text-center print:hidden">
                  <button class="text-red-500" @click="onLogRemove(index)">
                    <svg xmlns="http://www.w3.org/2000/svg" x="0px" y="0px" width="24" height="24" viewBox="0,0,300,150">
                      <g fill="#b91c1c" fill-rule="nonzero" stroke="none" stroke-width="1" stroke-linecap="butt" stroke-linejoin="miter" stroke-miterlimit="10" stroke-dasharray="" stroke-dashoffset="0" font-family="none" font-weight="none" font-size="none" text-anchor="none" style="mix-blend-mode: normal"><g transform="scale(16,16)"><path d="M6.49609,1c-0.82031,0 -1.49609,0.67578 -1.49609,1.49609v0.50391h-3v1h1v8.5c0,0.82813 0.67188,1.5 1.5,1.5h6c0.82813,0 1.5,-0.67187 1.5,-1.5v-8.5h1v-1h-3v-0.50391c0,-0.82031 -0.67578,-1.49609 -1.49609,-1.49609zM6.49609,2h2.00781c0.28125,0 0.49609,0.21484 0.49609,0.49609v0.50391h-3v-0.50391c0,-0.28125 0.21484,-0.49609 0.49609,-0.49609zM5,5h1v7h-1zM7,5h1v7h-1zM9,5h1v7h-1z"></path></g></g>
                    </svg>
                  </button>
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>

      <!-- You can use $pwa directly in templates! -->
      <div v-show="$pwa.needRefresh" class="py-8">
        <span>
          New content available, click on reload button to update.
        </span>

        <button class="font-semibold text-indigo-500 hover:text-indigo-400" @click="$pwa.updateServiceWorker()">
          Reload
        </button>
      </div>
    </div>
  </div>
</template>
